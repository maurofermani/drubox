Title: Xedia

Author:  Photoshopedia
                 http://www.photoshopedia.com/

License:  The icons are free to use for both personal and commercial projects. You are not allowed to sell these brushes. You can share or redistribute these brushes, but a link back to Photoshopedia is required.

� All rights reserved Photoshopedia - http://www.photoshopedia.com/